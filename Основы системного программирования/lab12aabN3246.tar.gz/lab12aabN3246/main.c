#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <dlfcn.h>
#include <unistd.h>
#include <getopt.h>

#define MAX_PATH_LEN 1024
#define PLUGIN_DIR "./plugin"  // Папка, где хранятся плагины

// Структура для плагинов
typedef struct plugin {
    void (*plugin_get_info)(void);  // Функция для получения информации о плагине
    int (*plugin_process_file)(const char* filename);  // Функция для обработки файла
} plugin_t;

// Структура для хранения опций
typedef struct options {
    int logical_and;  // Если 1, то операция "И", если 0, то "ИЛИ"
    int invert;  // Если 1, то инвертировать результат
    char* plugin_dir;  // Каталог для поиска плагинов
    int exe_flag;  // Флаг для поиска исполняемых файлов
    int crc_flag;  // Флаг для поиска по CRC16
    char* crc_value; // Значение CRC16 для поиска
} options_t;

// Функция для поиска плагинов в каталоге
void load_plugins(plugin_t** plugins, int* plugin_count, const char* plugin_dir) {
    DIR* dir = opendir(plugin_dir);
    if (!dir) {
        perror("opendir");
        return;
    }

    struct dirent* entry;
    char path[MAX_PATH_LEN];
    *plugin_count = 0;

    while ((entry = readdir(dir)) != NULL) {
        // Пропускаем скрытые файлы и директории
        if (entry->d_name[0] == '.' || strstr(entry->d_name, ".so") == NULL) continue;

        snprintf(path, MAX_PATH_LEN, "%s/%s", plugin_dir, entry->d_name);

        // Загружаем плагин
        void* handle = dlopen(path, RTLD_LAZY);
        if (!handle) {
            fprintf(stderr, "Failed to load plugin: %s\n", dlerror());
            continue;
        }

        // Выделяем память под новый плагин
        *plugin_count += 1;
        *plugins = realloc(*plugins, (*plugin_count) * sizeof(plugin_t));
        plugin_t* plugin = &(*plugins)[*plugin_count - 1];

        // Загружаем функции плагина
        plugin->plugin_get_info = dlsym(handle, "plugin_get_info");
        plugin->plugin_process_file = dlsym(handle, "plugin_process_file");

        if (!plugin->plugin_get_info || !plugin->plugin_process_file) {
            fprintf(stderr, "Failed to load plugin functions: %s\n", dlerror());
            dlclose(handle);
            (*plugin_count)--;
            continue;
        }

        printf("Plugin loaded: %s\n", path);
    }

    closedir(dir);
}

// Функция для рекурсивного обхода каталога
void search_directory(const char* directory, plugin_t* plugins, int plugin_count, options_t options) {
    DIR* dir = opendir(directory);
    if (!dir) {
        perror("opendir");
        return;
    }

    struct dirent* entry;
    char path[MAX_PATH_LEN];
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_name[0] == '.') continue;  // Пропускаем скрытые файлы

        snprintf(path, MAX_PATH_LEN, "%s/%s", directory, entry->d_name);
        struct stat statbuf;
        if (stat(path, &statbuf) == -1) {
            perror("stat");
            continue;
        }

        if (S_ISDIR(statbuf.st_mode)) {
            // Рекурсивный вызов для директорий
            search_directory(path, plugins, plugin_count, options);
        } else if (S_ISREG(statbuf.st_mode)) {
            // Обрабатываем файл с помощью всех плагинов
            for (int i = 0; i < plugin_count; i++) {
                int match = plugins[i].plugin_process_file(path);
                if (options.invert) {
                    match = !match;
                }

                if ((options.logical_and && match) || (!options.logical_and && match)) {
                    printf("Found file: %s\n", path);
                }
            }
        }
    }
    closedir(dir);
}

void print_help() {
    printf("Usage: lab12abcNXXXXX [options] [directory]\n");
    printf("Options:\n");
    printf("  -P <dir>    Directory with plugins (default is ./plugin)\n");
    printf("  -A          Combine plugin options with logical AND\n");
    printf("  -O          Combine plugin options with logical OR\n");
    printf("  -N          Invert the search condition\n");
    printf("  -v          Show version information\n");
    printf("  -h          Show help\n");
    printf("  --exe       Search for executable files\n");
    printf("  --crc16     Search for files with a specific CRC16\n");
}

void print_version() {
    printf("lab12abcNXXXXX version 1.0\n");
    printf("Author: Your Name, Group: N3246\n");
}

int main(int argc, char* argv[]) {
    options_t options = {1, 0, "./plugin", 0, 0, NULL};  // По умолчанию ищем плагины в ./plugin

    int opt;
    static struct option long_options[] = {
        {"exe", no_argument, NULL, 1},
        {"crc16", required_argument, NULL, 2},
        {0, 0, 0, 0}
    };

    while ((opt = getopt_long(argc, argv, "P:AOvNh", long_options, NULL)) != -1) {
        switch (opt) {
            case 'P':
                options.plugin_dir = optarg;
                break;
            case 'A':
                options.logical_and = 1;
                break;
            case 'O':
                options.logical_and = 0;
                break;
            case 'N':
                options.invert = 1;
                break;
            case 'v':
                print_version();
                return 0;
            case 'h':
                print_help();
                return 0;
            case 1:
                options.exe_flag = 1;
                break;
            case 2:
                options.crc_flag = 1;
                options.crc_value = optarg;  // CRC16 value passed as argument
                break;
            default:
                print_help();
                return 1;
        }
    }

    const char* directory = (argc > optind) ? argv[optind] : ".";  // Используем текущую директорию, если путь не задан

    plugin_t* plugins = NULL;
    int plugin_count = 0;

    // Загружаем плагины
    load_plugins(&plugins, &plugin_count, options.plugin_dir);

    if (plugin_count == 0) {
        fprintf(stderr, "No plugins found\n");
        return EXIT_FAILURE;
    }

    // Выполняем рекурсивный поиск файлов в указанном каталоге
    search_directory(directory, plugins, plugin_count, options);

    // Освобождаем память
    free(plugins);
    return EXIT_SUCCESS;
}
