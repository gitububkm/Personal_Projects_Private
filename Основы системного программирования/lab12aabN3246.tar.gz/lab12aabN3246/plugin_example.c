#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "plugin_api.h"

// Функция для проверки, является ли файл ELF
int is_elf_file(const char* filename) {
    FILE* file = fopen(filename, "rb");
    if (!file) {
        perror("fopen");
        return 0;
    }

    // Читаем первые 4 байта файла
    uint8_t magic[4];
    size_t read_size = fread(magic, 1, 4, file);
    fclose(file);

    // Проверка на магическое число ELF
    if (read_size == 4 && magic[0] == 0x7f && magic[1] == 0x45 && magic[2] == 0x4c && magic[3] == 0x46) {
        return 1;  // Это ELF файл
    }

    return 0;  // Не ELF файл
}

// Функция для получения информации о плагине
void plugin_get_info(void) {
    printf("Plugin supports the following option:\n");
    printf("--exe <value> - Find ELF executable files.\n");
}

// Функция для обработки файла
int plugin_process_file(const char* filename) {
    if (is_elf_file(filename)) {
        return 1;  // Возвращаем 1, если файл ELF
    }
    return 0;  // Иначе возвращаем 0
}
