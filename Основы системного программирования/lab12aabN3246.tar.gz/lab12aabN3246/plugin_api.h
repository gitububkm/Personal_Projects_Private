#ifndef PLUGIN_H
#define PLUGIN_H

// Функция для получения информации о поддерживаемых опциях плагина
void plugin_get_info(void);

// Функция для обработки файла
int plugin_process_file(const char* filename);

#endif // PLUGIN_H
