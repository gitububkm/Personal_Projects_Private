#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <getopt.h>

void print_help() {
    printf("Usage: lab11aabN3246 [options] <directory> <search_string>\n");
    printf("Options:\n");
    printf("-h, --help       Show this help message\n");
    printf("-v, --version    Show version info\n");
    printf("Environment Variables:\n");
    printf("LAB11DEBUG=1     Enable debug output\n");
}

void print_version() {
    printf("Program: lab11aabN3246\n");
    printf("Author: Bardyshev Artem\n");
    printf("Group: N3246\n");
    printf("Version: 1.0\n");
}

void debug_message(const char *msg) {
    char *debug = getenv("LAB11DEBUG");
    if (debug != NULL && strcmp(debug, "1") == 0) {
        fprintf(stderr, "DEBUG: %s\n", msg);
    }
}

int search_file(const char *filepath, const char *search_string) {
    FILE *file = fopen(filepath, "r");
    if (file == NULL) {
        return 0;
    }

    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), file) != NULL) {
        if (strstr(buffer, search_string) != NULL) {
            fclose(file);
            return 1;
        }
    }

    fclose(file);
    return 0;
}

void search_directory(const char *dir_path, const char *search_string) {
    DIR *dir = opendir(dir_path);
    if (dir == NULL) {
        perror("opendir");
        return;
    }

    struct dirent *entry;
    struct stat entry_stat;
    char filepath[1024];

    while ((entry = readdir(dir)) != NULL) {
        // Skip "." and ".."
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
            continue;
        }

        snprintf(filepath, sizeof(filepath), "%s/%s", dir_path, entry->d_name);
        stat(filepath, &entry_stat);

        // If it's a directory, recursively search it
        if (S_ISDIR(entry_stat.st_mode)) {
            search_directory(filepath, search_string);
        }
        // If it's a file, search the content
        else if (S_ISREG(entry_stat.st_mode)) {
            debug_message(filepath); // Debugging message if LAB11DEBUG is set
            if (search_file(filepath, search_string)) {
                printf("Found: %s\n", filepath);
            }
        }
    }

    closedir(dir);
}

int main(int argc, char *argv[]) {
    int opt;
    int help_flag = 0;
    int version_flag = 0;

    // Определение длинных опций
    static struct option long_options[] = {
        {"help", no_argument, NULL, 'h'},
        {"version", no_argument, NULL, 'v'},
        {0, 0, 0, 0}
    };

    // Разбор командных опций с использованием getopt_long
    while ((opt = getopt_long(argc, argv, "hv", long_options, NULL)) != -1) {
        switch (opt) {
            case 'v':
                version_flag = 1;
                break;
            case 'h':
                help_flag = 1;
                break;
            default:
                fprintf(stderr, "Usage: %s [-v] [-h] <directory> <search_string>\n", argv[0]);
                exit(EXIT_FAILURE);
        }
    }

    // Обработка флага --help
    if (help_flag) {
        print_help();
        exit(EXIT_SUCCESS);
    }

    // Обработка флага --version
    if (version_flag) {
        print_version();
        exit(EXIT_SUCCESS);
    }

    // Убедитесь, что переданы правильные аргументы
    if (argc - optind != 2) {
        fprintf(stderr, "Usage: %s [-v] [-h] <directory> <search_string>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    char *directory = argv[optind];
    char *search_string = argv[optind + 1];

    // Рекурсивный поиск
    search_directory(directory, search_string);

    return 0;
}
